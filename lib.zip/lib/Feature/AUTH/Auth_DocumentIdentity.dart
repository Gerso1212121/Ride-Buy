import 'dart:io';
import 'dart:typed_data';
import 'package:flutter/material.dart';
import 'package:camera/camera.dart';
import 'package:path_provider/path_provider.dart';
import 'package:http/http.dart' as http;

class DocScannerPage extends StatefulWidget {
  @override
  _DocScannerPageState createState() => _DocScannerPageState();
}

class _DocScannerPageState extends State<DocScannerPage> {
  CameraController? controller;
  late Future<void> _initFuture;

  @override
  void initState() {
    super.initState();
    _initFuture = initCamera();
  }

  Future<void> initCamera() async {
    final cameras = await availableCameras();
    final cam = cameras.firstWhere(
        (c) => c.lensDirection == CameraLensDirection.back,
        orElse: () => cameras.first);
    controller = CameraController(cam, ResolutionPreset.high, enableAudio: false);
    await controller!.initialize();
    if (mounted) setState(() {});
  }

  @override
  void dispose() {
    controller?.dispose();
    super.dispose();
  }

  Future<File> takePicture() async {
    final pic = await controller!.takePicture();
    final directory = await getTemporaryDirectory();
    final saved = await File(pic.path).copy('${directory.path}/doc_capture.jpg');
    return saved;
  }

  Future<void> _captureAndSend() async {
    final file = await takePicture();
    // enviar al backend/Azure como multipart
    final uri = Uri.parse('https://tu-backend.com/api/uploadDocument');
    final req = http.MultipartRequest('POST', uri);
    req.files.add(await http.MultipartFile.fromPath('file', file.path));
    final res = await req.send();
    if (res.statusCode == 200) {
      // manejar respuesta
    }
  }

  @override
  Widget build(BuildContext context) {
    return FutureBuilder(
      future: _initFuture,
      builder: (_, snapshot) {
        if (snapshot.connectionState != ConnectionState.done) {
          return const Center(child: CircularProgressIndicator());
        }
        return Scaffold(
          body: Stack(
            children: [
              CameraPreview(controller!),
              // Overlay semi-transparente con rectángulo central
              const Positioned.fill(child: DocumentOverlay()),
              Positioned(
                bottom: 30,
                left: 0,
                right: 0,
                child: Center(
                  child: FloatingActionButton(
                    onPressed: _captureAndSend,
                    child: const Icon(Icons.camera_alt),
                  ),
                ),
              ),
            ],
          ),
        );
      },
    );
  }
}

class DocumentOverlay extends StatelessWidget {
  const DocumentOverlay({super.key});
  @override
  Widget build(BuildContext context) {
    return LayoutBuilder(builder: (context, size) {
      return CustomPaint(
        size: Size(size.maxWidth, size.maxHeight),
        painter: _OverlayPainter(),
      );
    });
  }
}

class _OverlayPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paintMask = Paint()..color = Colors.black54;
    // dibuja fondo oscuro
    canvas.drawRect(Rect.fromLTWH(0, 0, size.width, size.height), paintMask);

    // rectángulo objetivo (80% ancho, 55% alto, centrado)
    final w = size.width * 0.9;
    final h = size.height * 0.55;
    final left = (size.width - w) / 2;
    final top = (size.height - h) / 2;
    final rect = Rect.fromLTWH(left, top, w, h);

    // borra la zona del rectángulo dejándola visible (usando BlendMode.clear)
    final clearPaint = Paint()..blendMode = BlendMode.clear;
    canvas.drawRect(rect, clearPaint);

    // dibuja borde del rectángulo y esquinas
    final border = Paint()
      ..color = Colors.white
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3;
    canvas.drawRect(rect, border);

    // esquinas
    final corner = Paint()
      ..color = Colors.greenAccent
      ..strokeWidth = 5
      ..style = PaintingStyle.stroke;
    const cornerLen = 24.0;
    // top-left
    canvas.drawLine(Offset(left, top), Offset(left + cornerLen, top), corner);
    canvas.drawLine(Offset(left, top), Offset(left, top + cornerLen), corner);
    // top-right
    canvas.drawLine(Offset(left + w, top), Offset(left + w - cornerLen, top), corner);
    canvas.drawLine(Offset(left + w, top), Offset(left + w, top + cornerLen), corner);
    // bottom-left
    canvas.drawLine(Offset(left, top + h), Offset(left + cornerLen, top + h), corner);
    canvas.drawLine(Offset(left, top + h), Offset(left, top + h - cornerLen), corner);
    // bottom-right
    canvas.drawLine(Offset(left + w, top + h), Offset(left + w - cornerLen, top + h), corner);
    canvas.drawLine(Offset(left + w, top + h), Offset(left + w, top + h - cornerLen), corner);
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}
